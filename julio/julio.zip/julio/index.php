<?php
include "template_parts/header.php";
 ?>

  <!--heroscreen-->
  <section id="index" class="container-fluid no-padding">
    <div class="col-12 no-padding">

      <div class="col-12 no-padding index-img imgLiquid imgLiquidFill">
        <img src="img/fondo1.jpg" alt="">
      </div>

      <div class=" col-12 index-text">

        <div class="row">

          <div class="col-12 my-auto ha">

            <h1 class="col-12 my-auto text-center">TITULO DE AGENCIA</h1>
            <p class="col-12 text-center"><span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Autem maiores repellendus possimus asperiores praesentium. Nulla, eum cupiditate ab natus beatae, qui ipsum aliquam quidem officiis eius veritatis eaque vel quia.</span>
              <span>Quam ipsam iure atque dolor minus. Esse eum totam velit natus, earum ducimus nulla? Ad delectus, rem doloremque optio perspiciatis id odio voluptas culpa voluptate doloribus minus nisi, officia eveniet!</span>
              <span>Reprehenderit enim impedit assumenda possimus exercitationem voluptates, commodi consequatur quam temporibus. Eveniet eos cupiditate minus nisi excepturi voluptates explicabo. Ipsam minima ipsa iste, ea sit nulla officia maxime, eligendi incidunt.</span></p>
            </div>

          </div>

        </div>
      </div>
    </section>

    <!--servicios-->

    <section id="index-servicios" class="container">

      <div class="row">
        <h1 class="col-12 text-center index-titulo">Servicios</h1>
        <!--servicio-->
        <div class="index-servicio col-4 no-padding">

          <div class="col-12 servicio-img">
            <div class="col-12 no-padding imgLiquid imgLiquidFill">
              <img src="img/placeholder.edit.png" alt="">
            </div>
          </div>

          <div class="col-12 index-text">

            <div class="row">
              <div class="col-12 ha my-auto">
                <h3 class="col-12 text-center">Servicio Dummie</h3>


              </div>

            </div>
          </div>
        </div>
        <!--fin servicio-->

        <!--servicio-->
        <div class="index-servicio col-4 no-padding">

          <div class="col-12 servicio-img">
            <div class="col-12 no-padding imgLiquid imgLiquidFill">
              <img src="img/placeholder.edit.png" alt="">
            </div>
          </div>

          <div class="col-12 index-text">

            <div class="row">
              <div class="col-12 ha my-auto">
                <h3 class="col-12 text-center">Servicio Dummie</h3>


              </div>

            </div>
          </div>
        </div>
        <!--fin servicio-->

        <!--servicio-->
        <div class="index-servicio col-4 no-padding">

          <div class="col-12 servicio-img">
            <div class="col-12 no-padding imgLiquid imgLiquidFill">
              <img src="img/placeholder.edit.png" alt="">
            </div>
          </div>

          <div class="col-12 index-text">

            <div class="row">
              <div class="col-12 ha my-auto">
                <h3 class="col-12 text-center">Servicio Dummie</h3>


              </div>

            </div>
          </div>
        </div>
        <!--fin servicio-->

        <!--servicio-->
        <div class="index-servicio col-4 no-padding">

          <div class="col-12 servicio-img">
            <div class="col-12 no-padding imgLiquid imgLiquidFill">
              <img src="img/placeholder.edit.png" alt="">
            </div>
          </div>

          <div class="col-12 index-text">

            <div class="row">
              <div class="col-12 ha my-auto">
                <h3 class="col-12 text-center">Servicio Dummie</h3>


              </div>

            </div>
          </div>
        </div>
        <!--fin servicio-->

        <!--servicio-->
        <div class="index-servicio col-4 no-padding">

          <div class="col-12 servicio-img">
            <div class="col-12 no-padding imgLiquid imgLiquidFill">
              <img src="img/placeholder.edit.png" alt="">
            </div>
          </div>

          <div class="col-12 index-text">

            <div class="row">
              <div class="col-12 ha my-auto">
                <h3 class="col-12 text-center">Servicio Dummie</h3>


              </div>

            </div>
          </div>
        </div>
        <!--fin servicio-->

        <!--servicio-->
        <div class="index-servicio col-4 no-padding">

          <div class="col-12 servicio-img">
            <div class="col-12 no-padding imgLiquid imgLiquidFill">
              <img src="img/placeholder.edit.png" alt="">
            </div>
          </div>

          <div class="col-12 index-text">

            <div class="row">
              <div class="col-12 ha my-auto">
                <h3 class="col-12 text-center">Servicio Dummie</h3>


              </div>

            </div>
          </div>
        </div>
        <!--fin servicio-->


      </div>

    </section>

<?php
include "template_parts/equipo.php"
?>

<?php
include "template_parts/footer.php";
?>
