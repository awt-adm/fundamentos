<footer class="container-fluid footer">

  <div class="row">
    <div class="col-12 col-md-6 text-left">
      <div class="row">
        <div class="col-12 ha my-auto">
          Copyright 2019
        </div>
      </div>
    </div>

    <div class="col-12 col-md-6 text-right">
      <div class="row">
        <div class="col-12 ha my-auto">
      <?php
include "template_parts/social.php"
       ?>
        </div>
      </div>
    </div>

  </div>

</footer>

<!-- scripts -->
<script src="js/jquery.js"></script>
<script src="js/slick.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/imgLiquid.js"></script>
<script src="js/app.js"></script>
<!-- fin de scripts -->
</body>
</html>
